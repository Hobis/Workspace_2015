﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.FlowLayoutPanel1 = New System.Windows.Forms.FlowLayoutPanel()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.TextBox_Style = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TextBox_Process = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TextBox_Size = New System.Windows.Forms.TextBox()
        Me.TextBox_Alpha = New System.Windows.Forms.TextBox()
        Me.TextBox_Caption = New System.Windows.Forms.TextBox()
        Me.TextBox_Class = New System.Windows.Forms.TextBox()
        Me.TextBox_Handle = New System.Windows.Forms.TextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.FlowLayoutPanel2 = New System.Windows.Forms.FlowLayoutPanel()
        Me.Button_Clear = New System.Windows.Forms.Button()
        Me.Button_Apply = New System.Windows.Forms.Button()
        Me.Button_About = New System.Windows.Forms.Button()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.FlowLayoutPanel1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.FlowLayoutPanel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.IsSplitterFixed = True
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.BackColor = System.Drawing.SystemColors.Control
        Me.SplitContainer1.Panel1.Controls.Add(Me.FlowLayoutPanel1)
        Me.SplitContainer1.Panel1.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.FlowLayoutPanel2)
        Me.SplitContainer1.Panel2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.SplitContainer1.Size = New System.Drawing.Size(424, 401)
        Me.SplitContainer1.SplitterDistance = 369
        Me.SplitContainer1.SplitterWidth = 1
        Me.SplitContainer1.TabIndex = 0
        Me.SplitContainer1.TabStop = False
        '
        'FlowLayoutPanel1
        '
        Me.FlowLayoutPanel1.Controls.Add(Me.GroupBox2)
        Me.FlowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.FlowLayoutPanel1.Name = "FlowLayoutPanel1"
        Me.FlowLayoutPanel1.Padding = New System.Windows.Forms.Padding(6)
        Me.FlowLayoutPanel1.Size = New System.Drawing.Size(424, 369)
        Me.FlowLayoutPanel1.TabIndex = 0
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.TextBox_Style)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.TextBox_Process)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.TextBox_Size)
        Me.GroupBox2.Controls.Add(Me.TextBox_Alpha)
        Me.GroupBox2.Controls.Add(Me.TextBox_Caption)
        Me.GroupBox2.Controls.Add(Me.TextBox_Class)
        Me.GroupBox2.Controls.Add(Me.TextBox_Handle)
        Me.GroupBox2.Controls.Add(Me.PictureBox1)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Location = New System.Drawing.Point(9, 9)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(381, 340)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Target Info"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(11, 240)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(71, 12)
        Me.Label7.TabIndex = 16
        Me.Label7.Text = "Wnd_Style: "
        '
        'TextBox_Style
        '
        Me.TextBox_Style.Location = New System.Drawing.Point(114, 237)
        Me.TextBox_Style.Name = "TextBox_Style"
        Me.TextBox_Style.Size = New System.Drawing.Size(255, 21)
        Me.TextBox_Style.TabIndex = 15
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(11, 213)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(68, 12)
        Me.Label6.TabIndex = 14
        Me.Label6.Text = "Wnd_Size: "
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(11, 186)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(75, 12)
        Me.Label5.TabIndex = 13
        Me.Label5.Text = "Wnd_Alpha: "
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(94, 77)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(94, 12)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "ProcessName: "
        '
        'TextBox_Process
        '
        Me.TextBox_Process.Location = New System.Drawing.Point(199, 74)
        Me.TextBox_Process.Name = "TextBox_Process"
        Me.TextBox_Process.ReadOnly = True
        Me.TextBox_Process.Size = New System.Drawing.Size(170, 21)
        Me.TextBox_Process.TabIndex = 11
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(11, 159)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(86, 12)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "Wnd_Caption: "
        '
        'TextBox_Size
        '
        Me.TextBox_Size.Location = New System.Drawing.Point(114, 210)
        Me.TextBox_Size.Name = "TextBox_Size"
        Me.TextBox_Size.Size = New System.Drawing.Size(255, 21)
        Me.TextBox_Size.TabIndex = 9
        '
        'TextBox_Alpha
        '
        Me.TextBox_Alpha.Location = New System.Drawing.Point(114, 183)
        Me.TextBox_Alpha.Name = "TextBox_Alpha"
        Me.TextBox_Alpha.Size = New System.Drawing.Size(255, 21)
        Me.TextBox_Alpha.TabIndex = 8
        '
        'TextBox_Caption
        '
        Me.TextBox_Caption.Location = New System.Drawing.Point(114, 156)
        Me.TextBox_Caption.Name = "TextBox_Caption"
        Me.TextBox_Caption.Size = New System.Drawing.Size(255, 21)
        Me.TextBox_Caption.TabIndex = 7
        '
        'TextBox_Class
        '
        Me.TextBox_Class.Location = New System.Drawing.Point(199, 47)
        Me.TextBox_Class.Name = "TextBox_Class"
        Me.TextBox_Class.ReadOnly = True
        Me.TextBox_Class.Size = New System.Drawing.Size(170, 21)
        Me.TextBox_Class.TabIndex = 6
        '
        'TextBox_Handle
        '
        Me.TextBox_Handle.Location = New System.Drawing.Point(199, 20)
        Me.TextBox_Handle.Name = "TextBox_Handle"
        Me.TextBox_Handle.ReadOnly = True
        Me.TextBox_Handle.Size = New System.Drawing.Size(170, 21)
        Me.TextBox_Handle.TabIndex = 5
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.PictureBox1.Location = New System.Drawing.Point(13, 26)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(60, 60)
        Me.PictureBox1.TabIndex = 4
        Me.PictureBox1.TabStop = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(94, 50)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(80, 12)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "ClassName: "
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(94, 23)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(82, 12)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "HandleCode: "
        '
        'FlowLayoutPanel2
        '
        Me.FlowLayoutPanel2.Controls.Add(Me.Button_Clear)
        Me.FlowLayoutPanel2.Controls.Add(Me.Button_Apply)
        Me.FlowLayoutPanel2.Controls.Add(Me.Button_About)
        Me.FlowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FlowLayoutPanel2.Location = New System.Drawing.Point(0, 0)
        Me.FlowLayoutPanel2.Name = "FlowLayoutPanel2"
        Me.FlowLayoutPanel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.FlowLayoutPanel2.Size = New System.Drawing.Size(424, 31)
        Me.FlowLayoutPanel2.TabIndex = 0
        '
        'Button_Clear
        '
        Me.Button_Clear.Location = New System.Drawing.Point(346, 3)
        Me.Button_Clear.Name = "Button_Clear"
        Me.Button_Clear.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Button_Clear.Size = New System.Drawing.Size(75, 24)
        Me.Button_Clear.TabIndex = 0
        Me.Button_Clear.Text = "Clear"
        Me.Button_Clear.UseVisualStyleBackColor = True
        '
        'Button_Apply
        '
        Me.Button_Apply.Location = New System.Drawing.Point(265, 3)
        Me.Button_Apply.Name = "Button_Apply"
        Me.Button_Apply.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Button_Apply.Size = New System.Drawing.Size(75, 24)
        Me.Button_Apply.TabIndex = 1
        Me.Button_Apply.Text = "Apply"
        Me.Button_Apply.UseVisualStyleBackColor = True
        '
        'Button_About
        '
        Me.Button_About.Location = New System.Drawing.Point(184, 3)
        Me.Button_About.Name = "Button_About"
        Me.Button_About.Padding = New System.Windows.Forms.Padding(0, 2, 0, 0)
        Me.Button_About.Size = New System.Drawing.Size(75, 24)
        Me.Button_About.TabIndex = 2
        Me.Button_About.Text = "About"
        Me.Button_About.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(424, 401)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        Me.SplitContainer1.ResumeLayout(False)
        Me.FlowLayoutPanel1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.FlowLayoutPanel2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents SplitContainer1 As System.Windows.Forms.SplitContainer
    Friend WithEvents FlowLayoutPanel2 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents Button_Clear As System.Windows.Forms.Button
    Friend WithEvents FlowLayoutPanel1 As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TextBox_Process As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TextBox_Size As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_Alpha As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_Caption As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_Class As System.Windows.Forms.TextBox
    Friend WithEvents TextBox_Handle As System.Windows.Forms.TextBox
    Friend WithEvents Button_Apply As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents TextBox_Style As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Button_About As System.Windows.Forms.Button

End Class
