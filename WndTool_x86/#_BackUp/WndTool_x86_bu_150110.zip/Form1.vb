﻿Imports System
Imports System.Drawing
Imports System.Windows.Forms
Imports System.Runtime.InteropServices
Imports System.Diagnostics
Imports System.Text

' # Form Code
Public NotInheritable Class Form1
    ' ::
    Private Sub p_Me_Load( _
                    ByVal sender As Object, _
                    ByVal ea As EventArgs) Handles MyBase.Load
        Me.Text = "WndTool_x86 Ver 1.2"
        Me.ClientSize = New Size(400, 400)
        Me.StartPosition = FormStartPosition.Manual
        Me.Location = New Point(100, 100)
        Me.AutoSizeMode = AutoSizeMode.GrowAndShrink
        Me.MaximizeBox = False

        AddHandler Me.PictureBox1.MouseUp, AddressOf Me.p_PictureBox1_MouseUp
        AddHandler Me.PictureBox1.MouseMove, AddressOf Me.p_PictureBox1_MouseMove
        AddHandler Me.PictureBox1.MouseDown, AddressOf Me.p_PictureBox1_MouseDown
    End Sub

    ' -
    Private _nowh As IntPtr

    ' ::
    Private Sub p_PictureBox1_MouseUp( _
                    ByVal sender As Object, _
                    ByVal mea As MouseEventArgs)
        If (mea.Button.Equals(MouseButtons.Left)) Then
            If (Not Me.Cursor.Equals(Cursors.Default)) Then
                Try
                    Me.Cursor = Cursors.Default
                Catch ex As Exception
                End Try

                Dim t_oh As IntPtr = HB_Win32.Get_OwnerHwnd(HB_Win32.WindowFromPoint(Cursor.Position))
                If (Not t_oh.Equals(IntPtr.Zero)) Then
                    Me._nowh = t_oh
                    Me.TextBox_Handle.Text = t_oh
                    Me.TextBox_Class.Text = HB_Win32.GetClassName_r(t_oh)
                    Me.TextBox_Caption.Text = HB_Win32.GetWindowText_r(t_oh)








                    'MessageBox.Show("t_oh: " & t_oh.ToString())

                    'Dim t_oc As Control = Control.FromHandle(t_oh)
                    't_oc.Text = "zzzzzzzz"
                    'HB_Win32.SetWindowTextW(t_oh, "실버라이트")

                    'Me.TextBox_Handle.Text = t_oh
                    'Me.TextBox_Class.Text = HB_Win32.GetClassName_r(t_oh)
                    ''Me.TextBox_Process.Text = Process.

                    'Me.TextBox_Caption.Text = HB_Win32.GetWindowText_r(t_oh)

                    'HB_Win32.SetWindowLongW(t_oh, HB_Win32.GWL_EXSTYLE, 0.2)
                    'MessageBox.Show("t_oh: " & t_oh.ToString())
                    'MessageBox.Show("t_oh: " & HB_Win32.GetWindowLongW(New HandleRef(Me, t_oh), _
                    '    HB_Win32.GWL_EXSTYLE))



                    'Const GWL_EXSTYLE As Integer = -20
                    'Const WS_EX_LAYERED As Integer = &H80000
                    'Const LWA_ALPHA As Integer = &H2
                    'Const LWA_COLORKEY As Integer = &H1
                    'HB_Win32.SetWindowLongW(t_oh, GWL_EXSTYLE, _
                    '    HB_Win32.GetWindowLongW(t_oh, GWL_EXSTYLE) ^ WS_EX_LAYERED)
                    'HB_Win32.SetLayeredWindowAttributes(t_oh, 0, 128, &H2)

                    'HB_Win32.SetWindowLongW(t_oh, -20, HB_Win32.GetWindowLongW(t_oh, -20) Or &H80000)
                    'HB_Win32.SetLayeredWindowAttributes(t_oh, 0, 255, &H2)

                    'MessageBox.Show(HB_Win32.GetWindowLongW(t_oh, -16).ToString())
                    'MessageBox.Show(HB_Win32.GetLayeredWindowAttributes(t_oh, -16, ).ToString())

                    'HB_Win32.SetLayeredWindowAttributes(t_oh, 0, 255, &H2)

                    'MessageBox.Show(HB_Win32.GetLayeredWindowAttributes(t_oh, -20).ToString())


                End If






                'Dim t_nh As IntPtr = HB_Win32.WindowFromPoint(Cursor.Position)
                'Dim t_th As IntPtr = t_nh
                'Dim t_oh As IntPtr = t_th
                'While (True)
                '    t_th = HB_Win32.GetParent(t_th)
                '    If (t_th.Equals(IntPtr.Zero)) Then
                '        Exit While
                '    Else
                '        t_oh = t_th
                '    End If
                'End While

                '                Dim t_oh As IntPtr = HB_Win32.Get_OwnerHwnd(HB_Win32.WindowFromPoint(Cursor.Position))
                'MessageBox.Show("t_oh: " & t_oh.ToString())

                'Dim t_oc As Control = Control.FromHandle(t_oh)
                'MessageBox.Show(": " & (t_oc Is Nothing).ToString())
                't_oc.Text = "zzzzzzzz"

                'MessageBox.Show(Me.Cursor.ToString())
                'MessageBox.Show(Cursor.ToString())
                'MessageBox.Show(Me.Cursor.Equals(Cursor))
                'MessageBox.Show(Windows.Forms.Cursor.Position.ToString())
                'MessageBox.Show("~~~: " & HB_Win32.WindowFromPoint(Cursor.Position).ToString())
                'MessageBox.Show("~~~: " & Control.MousePosition.ToString() & Cursor.Position.ToString())
                'MessageBox.Show("~~~: " & Cursor.Position.ToString())

                'Dim t_nh As IntPtr = HB_Win32.WindowFromPoint(Cursor.Position)
                'Dim t_nc As Control = Control.FromHandle(t_nh)
                'MessageBox.Show("t_nc: " & t_nc.ToString())
                'Dim t_ph As IntPtr = HB_Win32.GetParent(HB_Win32.GetParent(HB_Win32.GetParent(HB_Win32.GetParent(HB_Win32.GetParent(t_nh)))))
                'MessageBox.Show("t_nh: " & t_nh.ToString())
                'MessageBox.Show("t_ph: " & t_ph.ToString())
                'Process.GetProcessById(t_hwnd)

                'Dim t_nh As IntPtr = HB_Win32.WindowFromPoint(Cursor.Position)
                'Dim t_th As IntPtr = t_nh
                'Dim t_oh As IntPtr = t_th
                'While (True)
                '    t_th = HB_Win32.GetParent(t_th)
                '    If (t_th.Equals(IntPtr.Zero)) Then
                '        Exit While
                '    Else
                '        t_oh = t_th
                '    End If
                'End While
            End If
        End If
    End Sub

    ' ::
    Private Sub p_PictureBox1_MouseMove( _
                    ByVal sender As Object, _
                    ByVal mea As MouseEventArgs)
        If (Not Me.Cursor.Equals(Cursors.Default)) Then

        End If
    End Sub

    ' ::
    Private Sub p_PictureBox1_MouseDown( _
                    ByVal sender As Object, _
                    ByVal mea As MouseEventArgs)
        If (mea.Button.Equals(MouseButtons.Left)) Then
            Try
                Me.Cursor = Cursors.Cross
            Catch ex As Exception
            End Try
        End If
    End Sub

    ' ::
    Private Sub p_Button_Clear_Click( _
                    ByVal sender As Object, _
                    ByVal ea As EventArgs) Handles Button_Clear.Click
    End Sub
End Class


' # Win32 Util
Public Module HB_Win32
    ' ----
    <DllImport("user32.dll", _
        EntryPoint:="WindowFromPoint", _
        CharSet:=CharSet.Auto, _
        SetLastError:=True)>
    Public Function WindowFromPoint(ByVal p As Point) As IntPtr
    End Function

    <DllImport("user32.dll", _
        EntryPoint:="GetParent", _
        CharSet:=CharSet.Auto, _
        SetLastError:=True)>
    Public Function GetParent(ByVal hWnd As IntPtr) As IntPtr
    End Function

    <DllImport("user32.dll", _
        EntryPoint:="GetWindow", _
        CharSet:=CharSet.Auto, _
        SetLastError:=True)>
    Public Function GetWindow( _
                        ByVal hWnd As IntPtr, _
                        ByVal uCmd As UInteger) As IntPtr
    End Function

    ' ----
    <DllImport("user32.dll", _
        EntryPoint:="GetWindowTextLength", _
        CharSet:=CharSet.Auto, _
        SetLastError:=True)>
    Public Function GetWindowTextLength( _
                        ByVal hWnd As IntPtr) As Integer
    End Function

    <DllImport("user32.dll", _
        EntryPoint:="GetWindowText", _
        CharSet:=CharSet.Auto, _
        SetLastError:=True)>
    Public Function GetWindowText( _
                        ByVal hWnd As IntPtr, _
                        ByVal lpString As StringBuilder, _
                        ByVal nMaxCount As Integer) As Integer
    End Function

    <DllImport("user32.dll", _
        EntryPoint:="SetWindowText", _
        CharSet:=CharSet.Auto, _
        SetLastError:=True)>
    Public Function SetWindowText( _
                        ByVal hWnd As IntPtr, _
                        ByVal captio As String) As Boolean
    End Function

    Public Function GetWindowText_r(ByVal hWnd As IntPtr) As String
        'Dim t_l As Integer = GetWindowTextLengthW(hWnd)
        Dim t_l As Integer = 256
        Dim t_sb As StringBuilder = New StringBuilder(t_l + 1)
        GetWindowText(hWnd, t_sb, t_sb.Capacity)
        Return t_sb.ToString()
    End Function

    ' ----
    <DllImport("user32.dll", _
        EntryPoint:="GetClassName", _
        CharSet:=CharSet.Auto, _
        SetLastError:=True)>
    Public Function GetClassName( _
                        ByVal hWnd As IntPtr, _
                        ByVal lpClassName As StringBuilder, _
                        ByVal nMaxCount As Integer) As Integer
    End Function
    Public Function GetClassName_r(ByVal hWnd As IntPtr) As String
        Dim t_l As Integer = 256
        Dim t_sb As StringBuilder = New StringBuilder(t_l + 1)
        GetClassName(hWnd, t_sb, t_sb.Capacity)
        Return t_sb.ToString()
    End Function


    Public Const GWL_EXSTYLE As Integer = -20

    ' ----
    <DllImport("user32.dll", _
        EntryPoint:="GetWindowLong", _
        CharSet:=CharSet.Auto, _
        SetLastError:=True)>
    Public Function GetWindowLong( _
                        ByVal hWnd As IntPtr, _
                        ByVal nIndex As Integer) As Long
    End Function

    <DllImport("user32.dll", _
        EntryPoint:="SetWindowLong", _
        CharSet:=CharSet.Auto, _
        SetLastError:=True)>
    Public Function SetWindowLong( _
                        ByVal hWnd As IntPtr, _
                        ByVal nIndex As Integer, _
                        ByVal dwNewLong As Long) As Long
    End Function

    ' ----
    <DllImport("user32.dll", _
    EntryPoint:="GetLayeredWindowAttributes", _
    CharSet:=CharSet.Auto, _
    SetLastError:=True)>
    Public Function GetLayeredWindowAttributes( _
                        ByVal hWnd As IntPtr, _
                        ByRef crKey As UInteger, _
                        ByRef bAlpha As Byte, _
                        ByRef dwFlags As UInteger) As Boolean
    End Function

    <DllImport("user32.dll", _
        EntryPoint:="SetLayeredWindowAttributes", _
        CharSet:=CharSet.Auto, _
        SetLastError:=True)>
    Public Function SetLayeredWindowAttributes( _
                        ByVal hWnd As IntPtr, _
                        ByVal crKey As UInteger, _
                        ByVal bAlpha As Byte, _
                        ByVal dwFlags As UInteger) As Boolean
    End Function


    ' :: 최상위 오너핸들 가져오기
    Public Function Get_OwnerHwnd(ByVal hWnd As IntPtr) As IntPtr
        Dim t_th As IntPtr = hWnd
        Dim t_oh As IntPtr = t_th
        If (Not t_th.Equals(IntPtr.Zero)) Then
            While (True)
                t_th = HB_Win32.GetParent(t_th)
                If (t_th.Equals(IntPtr.Zero)) Then
                    Exit While
                Else
                    t_oh = t_th
                End If
            End While
        End If
        Return t_oh
    End Function

    ' :: HWnd에서 투명도값 가져오기
    Public Function Get_Opacity(ByVal hWnd As IntPtr) As Byte
        Dim t_rv As Byte
        Return t_rv
    End Function

    ' :: HWnd에서 투명도값 설정하기
    Public Function Set_Opacity(ByVal hWnd As IntPtr, ByVal v As Byte) As Boolean
        Dim t_rv As Boolean
        Return t_rv
    End Function
End Module
